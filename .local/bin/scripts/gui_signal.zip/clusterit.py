#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Mar  2 15:41:51 2025

@author: a420192
"""

import numpy as np
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score

# Example dataset: [Frame Thickness, Front Axle Load, Rear Axle Load, Acceleration at Hood, Grille, A-Pillar, B-Pillar]
data = np.array([
    [5.0, 2800, 1200, 3.2, 2.8, 4.5, 4.8],
    [6.5, 3100, 1500, 3.8, 3.1, 5.0, 5.2],
    [4.8, 2750, 1100, 2.9, 2.6, 4.2, 4.5],
    [7.0, 3300, 1700, 4.1, 3.5, 5.2, 5.6],
    [5.5, 2900, 1300, 3.4, 3.0, 4.7, 5.0],
    [6.2, 3050, 1400, 3.6, 3.2, 4.9, 5.3]
])

# Normalize features (optional)
scaler = StandardScaler()
data_scaled = scaler.fit_transform(data)

# Apply K-Means clustering
num_clusters = 3
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
labels = kmeans.fit_predict(data_scaled)

# Evaluate clustering performance
silhouette = silhouette_score(data_scaled, labels)
print(f"Silhouette Score: {silhouette:.2f}")

# Apply PCA for visualization (reduce dimensions to 2D)
pca = PCA(n_components=2)
data_pca = pca.fit_transform(data_scaled)

# Scatter plot of clusters
plt.scatter(data_pca[:, 0], data_pca[:, 1], c=labels, cmap='viridis', edgecolors='k')
plt.xlabel("Principal Component 1")
plt.ylabel("Principal Component 2")
plt.title("FEA Model Clustering Based on Acceleration")
plt.colorbar(label="Cluster")
plt.show()
