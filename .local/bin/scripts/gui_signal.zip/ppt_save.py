#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 20:40:06 2024

@author: a420192
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.text import PP_ALIGN
from pptx.dml.color import RGBColor

# Create a presentation object
prs = Presentation()

# Add a slide
slide_layout = prs.slide_layouts[5]  # Use a blank slide layout
slide = prs.slides.add_slide(slide_layout)

# Add images to the slide
image_paths = ["image1.png", "image2.png", "image3.png"]  # Paths to your images
image_positions = [(Inches(1), Inches(1)), (Inches(4), Inches(1)), (Inches(7), Inches(1))]

for path, (left, top) in zip(image_paths, image_positions):
    slide.shapes.add_picture(path, left, top, width=Inches(2), height=Inches(2))

# Add a table below the images
rows, cols = 4, 3  # Adjust rows and columns as needed
left = Inches(1)
top = Inches(3.5)
width = Inches(6)
height = Inches(1.5)

table = slide.shapes.add_table(rows, cols, left, top, width, height).table

# Fill table headers and content
headers = ["Column 1", "Column 2", "Column 3"]
for col, header in enumerate(headers):
    cell = table.cell(0, col)
    cell.text = header
    cell.text_frame.paragraphs[0].font.bold = True
    cell.text_frame.paragraphs[0].font.size = Pt(12)
    cell.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

# Sample data for the table
data = [
    ["Row 1, Col 1", "Row 1, Col 2", "Row 1, Col 3"],
    ["Row 2, Col 1", "Row 2, Col 2", "Row 2, Col 3"],
    ["Row 3, Col 1", "Row 3, Col 2", "Row 3, Col 3"]
]

# Insert data into table
for row in range(1, rows):
    for col in range(cols):
        cell = table.cell(row, col)
        cell.text = data[row - 1][col]
        cell.text_frame.paragraphs[0].font.size = Pt(10)
        cell.text_frame.paragraphs[0].alignment = PP_ALIGN.CENTER

# Save the presentation
prs.save("output_presentation.pptx")
