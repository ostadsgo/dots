#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Oct 27 08:32:42 2024

@author: a420192
"""
import numpy as np

# Original data
time = np.array([0, 1, 2, 3, 4, 5, 6, 7])
amplitude = np.array([10, 11, 15, 13, 12, 14, 10, 9])
print(time)
print(amplitude)
# Step 1: Define the condition to select the cropped portion (3 to 5 seconds)
condition = (time >= 3) & (time <= 5)

# Step 2: Get cropped time and amplitude data based on the condition
cropped_time = time[condition]
cropped_amplitude = amplitude[condition]

# Step 3: Offset cropped time to continue from the last value in the cropped portion (5 seconds)
time_increment = np.diff(cropped_time).mean()  # Mean increment in cropped time
time_offset = np.arange(5 + time_increment, 5 + (len(cropped_time)) * time_increment, time_increment)

# Step 4: Find index of 5 seconds and insert
insert_index = np.where(time == 5)[0][0] + 1  # Inserting right after 5 seconds

# Step 5: Concatenate original and new portions at the insertion point
extended_time = np.concatenate((time[:insert_index], time_offset, time[insert_index:]))
extended_amplitude = np.concatenate((amplitude[:insert_index], cropped_amplitude, amplitude[insert_index:]))

print("Extended Time:", extended_time)
print("Extended Amplitude:", extended_amplitude)
